
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, Save, Loader2, ExternalLink, Type, Shield, Clock, Users, Heart, Plus, Trash, FileText, Mail, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import DynamicList from "../components/settings/DynamicList";

export default function Settings() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    register_form_url: "",
    unregister_form_url: "",
    publish_apartment_url: "",
    remove_apartment_url: "",
    example_file_url: "",
    site_title: "שיתופים",
    site_tagline: "לוח דירות חכם",
    hero_badge: "לוח דירות חכם וקהילתי",
    hero_title: "מוצאים דירה ביחד, בקלות ובפשטות",
    hero_description: "פלטפורמה קהילתית ייחודית שמחברת בין מחפשי דירות למפרסמים, עם התאמה אישית מלאה לצרכים שלכם",
    hero_buttons: [
      { text: "הרשמה לקבלת עדכונים", url: "", style: "primary" },
      { text: "פרסום דירה", url: "", style: "secondary" }
    ],
    how_it_works_title: "איך זה עובד?",
    how_it_works_subtitle: "תהליך פשוט ומהיר בשלושה שלבים",
    steps: [
      {
        title: "1. מפרסמים מוסיפים דירות",
        description: "בעלי דירות ממלאים טופס פשוט עם כל הפרטים הרלוונטיים - מיקום, מחיר, מספר חדרים ועוד"
      },
      {
        title: "2. מתעניינים נרשמים לעדכונים",
        description: "מחפשי דירות מגדירים את העדפותיהם - אזור, תקציב, מספר חדרים והמערכת תתאים עבורם"
      },
      {
        title: "3. מקבלים התאמות מושלמות",
        description: "המערכת שולחת לכם רק דירות שמתאימות בדיוק למה שחיפשתם - חוסכת זמן ומאמץ"
      }
    ],
    stats_title: "המערכת שלנו במספרים",
    stats_subtitle: "נתונים וסטטיסטיקות",
    stats: [],
    features_title: "פיצ'רים ויכולות",
    features_subtitle: "מה המערכת מציעה",
    features: [],
    show_file_info: true, // New field
    file_info_title: "מקבלים קובץ מתעדכן אונליין", // New field
    file_info_description: "כאשר נרשמים למערכת, מקבלים גישה לקובץ Google Sheets שמתעדכן אוטומטית בזמן אמת עם כל הדירות המתאימות להעדפות שלכם - מיקום, תקציב, מספר חדרים ועוד. הקובץ נשאר תמיד מעודכן ונגיש מכל מקום!", // New field
    show_email_alerts_info: true, // New field
    email_alerts_title: "התראות מיידיות על דירות חדשות", // New field
    email_alerts_description: "בנוסף לקובץ המתעדכן, תוכלו לבחור לקבל גם התראות במייל כשנוספת דירה חדשה שמתאימה בדיוק להעדפות שלכם - כך לא תפספסו אף הזדמנות!", // New field
    show_email_only_option: true, // New field
    email_only_title: "עבור חסומי רשת - אפשרות מייל בלבד", // New field
    email_only_description: "אם אתם חסומים לרשת או מעדיפים לקבל את המידע רק במייל ללא גישה לקובץ אונליין, ציינו זאת בטופס ההרשמה ונתאים לכם פתרון מותאם אישית.", // New field
    benefits_title: "למה שיתופים?",
    benefits_subtitle: "הפלטפורמה המתקדמת והידידותית ביותר לחיפוש דירות",
    benefits: [
      { title: "מתקדם וחכם", description: "פיצ'רים חכמים למקסימום נוחות", icon: "Shield" },
      { title: "חוסך זמן", description: "רק דירות שמתאימות לכם בדיוק", icon: "Clock" },
      { title: "קהילתי", description: "מבוסס על שיתוף ושקיפות", icon: "Users" },
      { title: "התאמה אישית", description: "מערכת חכמה שמתאימה לצרכים שלכם", icon: "Heart" }
    ],
    actions_title: "פעולות מהירות",
    actions_subtitle: "בחרו את הפעולה המתאימה עבורכם",
    quick_actions: [
      { title: "הרשמה לקבלת עדכונים", description: "קבלו התראות על דירות שמתאימות להעדפות שלכם", url: "", color: "blue" },
      { title: "פרסום דירה חדשה", description: "יש לכם דירה להשכרה או למכירה? שתפו אותה עם הקהילה", url: "", color: "green" },
      { title: "הפסקת קבלת עדכונים", description: "מצאתם דירה? תוכלו להפסיק את קבלת העדכונים", url: "", color: "orange" },
      { title: "הסרת דירה מהמערכת", description: "הדירה הושכרה או נמכרה? הסירו אותה מהמערכת", url: "", color: "purple" }
    ],
    contact_title: "יש לכם שאלות? נשמח לעזור",
    contact_subtitle: "צרו איתנו קשר ונחזור אליכם בהקדם",
    contact_email: "contact@example.com"
  });

  const [isExporting, setIsExporting] = useState(false);
  const [isCopying, setIsCopying] = useState(false);
  const [isExportingAd, setIsExportingAd] = useState(false);
  const [isCopyingAd, setIsCopyingAd] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [exportAdSuccess, setExportAdSuccess] = useState(false);
  const [copyAdSuccess, setCopyAdSuccess] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    const checkUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        if (currentUser.role !== 'admin') {
          window.location.href = '/';
        }
      } catch (error) {
        window.location.href = '/';
      }
      setLoading(false);
    };
    checkUser();
  }, []);

  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list();
      return list[0] || null;
    },
    enabled: !loading && user?.role === 'admin'
  });

  useEffect(() => {
    if (settings) {
      setFormData({
        register_form_url: settings.register_form_url || "",
        unregister_form_url: settings.unregister_form_url || "",
        publish_apartment_url: settings.publish_apartment_url || "",
        remove_apartment_url: settings.remove_apartment_url || "",
        example_file_url: settings.example_file_url || "",
        site_title: settings.site_title || "שיתופים",
        site_tagline: settings.site_tagline || "לוח דירות חכם",
        hero_badge: settings.hero_badge || "לוח דירות חכם וקהילתי",
        hero_title: settings.hero_title || "מוצאים דירה ביחד, בקלות ובפשטות",
        hero_description: settings.hero_description || "פלטפורמה קהילתית ייחודית שמחברת בין מחפשי דירות למפרסמים, עם התאמה אישית מלאה לצרכים שלכם",
        hero_buttons: settings.hero_buttons || [
          { text: "הרשמה לקבלת עדכונים", url: "", style: "primary" },
          { text: "פרסום דירה", url: "", style: "secondary" }
        ],
        how_it_works_title: settings.how_it_works_title || "איך זה עובד?",
        how_it_works_subtitle: settings.how_it_works_subtitle || "תהליך פשוט ומהיר בשלושה שלבים",
        steps: settings.steps || [
          { title: "1. מפרסמים מוסיפים דירות", description: "בעלי דירות ממלאים טופס פשוט עם כל הפרטים הרלוונטיים - מיקום, מחיר, מספר חדרים ועוד" },
          { title: "2. מתעניינים נרשמים לעדכונים", description: "מחפשי דירות מגדירים את העדפותיהם - אזור, תקציב, מספר חדרים והמערכת תתאים עבורם" },
          { title: "3. מקבלים התאמות מושלמות", description: "המערכת שולחת לכם רק דירות שמתאימות בדיוק למה שחיפשתם - חוסכת זמן ומאמץ" }
        ],
        stats_title: settings.stats_title || "המערכת שלנו במספרים",
        stats_subtitle: settings.stats_subtitle || "נתונים וסטטיסטיקות",
        stats: settings.stats || [],
        features_title: settings.features_title || "פיצ'רים ויכולות",
        features_subtitle: settings.features_subtitle || "מה המערכת מציעה",
        features: settings.features || [],
        show_file_info: settings.show_file_info !== undefined ? settings.show_file_info : true,
        file_info_title: settings.file_info_title || "מקבלים קובץ מתעדכן אונליין",
        file_info_description: settings.file_info_description || "כאשר נרשמים למערכת, מקבלים גישה לקובץ Google Sheets שמתעדכן אוטומטית בזמן אמת עם כל הדירות המתאימות להעדפות שלכם - מיקום, תקציב, מספר חדרים ועוד. הקובץ נשאר תמיד מעודכן ונגיש מכל מקום!",
        show_email_alerts_info: settings.show_email_alerts_info !== undefined ? settings.show_email_alerts_info : true,
        email_alerts_title: settings.email_alerts_title || "התראות מיידיות על דירות חדשות",
        email_alerts_description: settings.email_alerts_description || "בנוסף לקובץ המתעדכן, תוכלו לבחור לקבל גם התראות במייל כשנוספת דירה חדשה שמתאימה בדיוק להעדפות שלכם - כך לא תפספסו אף הזדמנות!",
        show_email_only_option: settings.show_email_only_option !== undefined ? settings.show_email_only_option : true,
        email_only_title: settings.email_only_title || "עבור חסומי רשת - אפשרות מייל בלבד",
        email_only_description: settings.email_only_description || "אם אתם חסומים לרשת או מעדיפים לקבל את המידע רק במייל ללא גישה לקובץ אונליין, ציינו זאת בטופס ההרשמה ונתאים לכם פתרון מותאם אישית.",
        benefits_title: settings.benefits_title || "למה שיתופים?",
        benefits_subtitle: settings.benefits_subtitle || "הפלטפורמה המתקדמת והידידותית ביותר לחיפוש דירות",
        benefits: settings.benefits || [
          { title: "מתקדם וחכם", description: "פיצ'רים חכמים למקסימום נוחות", icon: "Shield" },
          { title: "חוסך זמן", description: "רק דירות שמתאימות לכם בדיוק", icon: "Clock" },
          { title: "קהילתי", description: "מבוסס על שיתוף ושקיפות", icon: "Users" },
          { title: "התאמה אישית", description: "מערכת חכמה שמתאימה לצרכים שלכם", icon: "Heart" }
        ],
        actions_title: settings.actions_title || "פעולות מהירות",
        actions_subtitle: settings.actions_subtitle || "בחרו את הפעולה המתאימה עבורכם",
        quick_actions: settings.quick_actions || [
          { title: "הרשמה לקבלת עדכונים", description: "קבלו התראות על דירות שמתאימות להעדפות שלכם", url: "", color: "blue" },
          { title: "פרסום דירה חדשה", description: "יש לכם דירה להשכרה או למכירה? שתפו אותה עם הקהילה", url: "", color: "green" },
          { title: "הפסקת קבלת עדכונים", description: "מצאתם דירה? תוכלו להפסיק את קבלת העדכונים", url: "", color: "orange" },
          { title: "הסרת דירה מהמערכת", description: "הדירה הושכרה או נמכרה? הסירו אותה מהמערכת", url: "", color: "purple" }
        ],
        contact_title: settings.contact_title || "יש לכם שאלות? נשמח לעזור",
        contact_subtitle: settings.contact_subtitle || "צרו איתנו קשר ונחזור אליכם בהקדם",
        contact_email: settings.contact_email || "contact@example.com"
      });
    }
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (settings) {
        return await base44.entities.Settings.update(settings.id, data);
      } else {
        return await base44.entities.Settings.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['settings'] });
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const handleExportPDF = async () => {
    setIsExporting(true);
    setExportSuccess(false);

    try {
      const htmlContent = `
<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${formData.site_title}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #eff6ff 0%, #f0fdf4 100%);
            padding: 40px 20px;
            line-height: 1.6;
            direction: rtl;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #2563eb 0%, #16a34a 100%);
            color: white;
            padding: 60px 40px;
            text-align: center;
        }
        .header h1 {
            font-size: 48px;
            font-weight: 800;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .header p {
            font-size: 22px;
            opacity: 0.95;
        }
        .content {
            padding: 50px 40px;
        }
        .hero {
            background: linear-gradient(135deg, #eff6ff 0%, #f0fdf4 100%);
            padding: 40px;
            border-radius: 16px;
            margin-bottom: 50px;
            border: 2px solid #e0f2fe;
            text-align: right;
        }
        .hero h2 {
            color: #1e40af;
            font-size: 32px;
            margin-bottom: 20px;
            font-weight: 700;
        }
        .hero p {
            color: #4b5563;
            font-size: 18px;
            line-height: 1.8;
            margin-bottom: 30px;
        }
        .hero-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .hero-buttons a {
            padding: 15px 30px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            font-size: 16px;
            transition: all 0.3s;
            display: inline-block;
        }
        .hero-buttons a.primary {
            background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.3);
        }
        .hero-buttons a.secondary {
            background: white;
            color: #2563eb;
            border: 2px solid #2563eb;
        }
        .section {
            margin-bottom: 50px;
        }
        .section-title {
            color: #1e40af;
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 15px;
            text-align: center;
        }
        .section-subtitle {
            color: #6b7280;
            font-size: 18px;
            text-align: center;
            margin-bottom: 40px;
        }
        .steps {
            display: grid;
            gap: 25px;
        }
        .step {
            background: #f9fafb;
            padding: 30px;
            border-radius: 16px;
            border-right: 5px solid #2563eb;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            text-align: right;
        }
        .step h3 {
            color: #2563eb;
            font-size: 24px;
            margin-bottom: 15px;
            font-weight: 700;
        }
        .step p {
            color: #4b5563;
            font-size: 16px;
            line-height: 1.8;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        .stat-card {
            background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
            padding: 30px;
            border-radius: 16px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border: 2px solid #bfdbfe;
        }
        .stat-card .value {
            font-size: 42px;
            font-weight: 800;
            background: linear-gradient(135deg, #2563eb 0%, #16a34a 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }
        .stat-card .title {
            font-weight: 700;
            color: #1f2937;
            font-size: 18px;
            margin-bottom: 8px;
        }
        .stat-card .description {
            color: #6b7280;
            font-size: 14px;
        }
        .features-grid {
            display: grid;
            gap: 20px;
            margin-top: 30px;
        }
        .feature-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            border-right: 4px solid #16a34a;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            text-align: right;
        }
        .feature-card h4 {
            color: #1f2937;
            font-size: 20px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .feature-card h4:before {
            content: "✓ ";
            color: #16a34a;
            font-weight: 800;
            margin-left: 5px;
        }
        .feature-card p {
            color: #6b7280;
            font-size: 15px;
            line-height: 1.6;
        }
        .info-card {
          background: linear-gradient(135deg, #f0f9ff 0%, #f0fdf4 100%);
          padding: 30px;
          border-radius: 16px;
          box-shadow: 0 4px 15px rgba(0,0,0,0.08);
          border-left: 5px solid #2563eb;
          margin-bottom: 30px;
        }
        .info-card h3 {
          color: #1e40af;
          font-size: 24px;
          font-weight: 700;
          margin-bottom: 10px;
        }
        .info-card p {
          color: #4b5563;
          font-size: 16px;
          line-height: 1.7;
        }
        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        .benefit-card {
            background: linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%);
            padding: 30px;
            border-radius: 16px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border: 2px solid #e5e7eb;
        }
        .benefit-card .icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        .benefit-card h4 {
            color: #1f2937;
            font-size: 20px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .benefit-card p {
            color: #6b7280;
            font-size: 15px;
        }
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        .action-card {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border-top: 4px solid;
            text-align: right;
        }
        .action-card.blue { border-top-color: #2563eb; }
        .action-card.green { border-top-color: #16a34a; }
        .action-card.orange { border-top-color: #f97316; }
        .action-card.purple { border-top-color: #9333ea; }
        .action-card h4 {
            color: #1f2937;
            font-size: 20px;
            margin-bottom: 15px;
            font-weight: 700;
        }
        .action-card p {
            color: #6b7280;
            font-size: 15px;
            margin-bottom: 20px;
            line-height: 1.6;
        }
        .action-card a {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 700;
            color: white;
            font-size: 15px;
        }
        .action-card.blue a { background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); }
        .action-card.green a { background: linear-gradient(135deg, #16a34a 0%, #15803d 100%); }
        .action-card.orange a { background: linear-gradient(135deg, #f97316 0%, #ea580c 100%); }
        .action-card.purple a { background: linear-gradient(135deg, #9333ea 0%, #7e22ce 100%); }
        .contact {
            background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
            padding: 50px;
            border-radius: 16px;
            text-align: center;
            margin-top: 50px;
            border: 2px solid #bfdbfe;
        }
        .contact h2 {
            color: #1e40af;
            font-size: 32px;
            margin-bottom: 15px;
            font-weight: 700;
        }
        .contact p {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 20px;
        }
        .contact a {
            color: #2563eb;
            font-size: 22px;
            font-weight: 700;
            text-decoration: none;
        }
        .footer {
            background: #1f2937;
            color: white;
            padding: 30px;
            text-align: center;
        }
        .footer p {
            font-size: 14px;
            opacity: 0.8;
        }
        
        /* כללים מיוחדים להדפסה ויצירת PDF */
        @media print {
            body {
                padding: 0;
                background: white;
            }
            .container {
                box-shadow: none;
                border-radius: 0;
                max-width: 100%;
            }
            .header {
                background: #2563eb !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                color-adjust: exact;
                page-break-after: avoid;
            }
            .content {
                padding: 30px;
            }
            .hero {
                background: #eff6ff !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                border: 2px solid #bfdbfe;
                page-break-inside: avoid;
            }
            .step, .stat-card, .feature-card, .benefit-card, .action-card, .info-card {
                page-break-inside: avoid;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .stat-card {
                background: #eff6ff !important;
            }
            .stat-card .value {
                color: #2563eb !important;
                -webkit-text-fill-color: #2563eb !important;
            }
            .benefit-card {
                background: #f9fafb !important;
            }
            .contact {
                background: #eff6ff !important;
                page-break-inside: avoid;
            }
            .footer {
                background: #1f2937 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .section {
                page-break-inside: avoid;
            }
            .section-title {
                page-break-after: avoid;
            }
            a {
                text-decoration: underline;
            }
            .hero-buttons a, .action-card a {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>${formData.site_title}</h1>
            <p>${formData.site_tagline}</p>
        </div>
        
        <div class="content">
            <div class="hero">
                <h2>${formData.hero_title}</h2>
                <p>${formData.hero_description}</p>
                <div class="hero-buttons">
                    ${formData.hero_buttons.map(button => button.url ? `
                        <a href="${button.url}" class="${button.style}" target="_blank">${button.text}</a>
                    ` : '').join('')}
                </div>
            </div>

            <div class="section">
                <h2 class="section-title">${formData.how_it_works_title}</h2>
                <p class="section-subtitle">${formData.how_it_works_subtitle}</p>
                <div class="steps">
                    ${formData.steps.map(step => `
                        <div class="step">
                            <h3>${step.title}</h3>
                            <p>${step.description}</p>
                        </div>
                    `).join('')}
                </div>
            </div>

            ${formData.stats && formData.stats.length > 0 ? `
            <div class="section">
                <h2 class="section-title">${formData.stats_title}</h2>
                <p class="section-subtitle">${formData.stats_subtitle}</p>
                <div class="stats-grid">
                    ${formData.stats.map(stat => `
                        <div class="stat-card">
                            <div class="value">${stat.value}</div>
                            <div class="title">${stat.title}</div>
                            <div class="description">${stat.description}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
            ` : ''}

            ${formData.features && formData.features.length > 0 ? `
            <div class="section">
                <h2 class="section-title">${formData.features_title}</h2>
                <p class="section-subtitle">${formData.features_subtitle}</p>
                <div class="features-grid">
                    ${formData.features.map(feature => `
                        <div class="feature-card">
                            <h4>${feature.title}</h4>
                            <p>${feature.description}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
            ` : ''}

            ${formData.show_file_info ? `
            <div class="section">
                <div class="info-card">
                    <h3>${formData.file_info_title}</h3>
                    <p>${formData.file_info_description}</p>
                </div>
            </div>
            ` : ''}

            ${formData.show_email_alerts_info ? `
            <div class="section">
                <div class="info-card">
                    <h3>${formData.email_alerts_title}</h3>
                    <p>${formData.email_alerts_description}</p>
                </div>
            </div>
            ` : ''}

            <div class="section">
                <h2 class="section-title">${formData.benefits_title}</h2>
                <p class="section-subtitle">${formData.benefits_subtitle}</p>
                <div class="benefits-grid">
                    ${formData.benefits.map(benefit => `
                        <div class="benefit-card">
                            <div class="icon">${benefit.icon === 'Shield' ? '🛡️' : benefit.icon === 'Clock' ? '⏰' : benefit.icon === 'Users' ? '👥' : benefit.icon === 'Heart' ? '❤️' : benefit.icon === 'Star' ? '⭐' : '⚡'}</div>
                            <h4>${benefit.title}</h4>
                            <p>${benefit.description}</p>
                        </div>
                    `).join('')}
                </div>
            </div>

            <div class="section">
                <h2 class="section-title">${formData.actions_title}</h2>
                <p class="section-subtitle">${formData.actions_subtitle}</p>
                <div class="actions-grid">
                    ${formData.quick_actions.map(action => `
                        <div class="action-card ${action.color}">
                            <h4>${action.title}</h4>
                            <p>${action.description}</p>
                            ${action.url ? `<a href="${action.url}" target="_blank">לחץ כאן</a>` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>

            <div class="contact">
                <h2>${formData.contact_title}</h2>
                <p>${formData.contact_subtitle}</p>
                <a href="mailto:${formData.contact_email}">${formData.contact_email}</a>
            </div>

            ${formData.show_email_only_option ? `
            <div class="section" style="text-align: center; margin-top: 30px; font-size: 14px; color: #6b7280;">
                <p><strong>${formData.email_only_title}</strong></p>
                <p>${formData.email_only_description}</p>
            </div>
            ` : ''}
        </div>

        <div class="footer">
            <p>© ${new Date().getFullYear()} ${formData.site_title} - כל הזכויות שמורות</p>
        </div>
    </div>
</body>
</html>
      `;

      // הורדת הקובץ
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${formData.site_title}_מסמך_מלא.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 5000);
    } catch (error) {
      console.error("Error exporting:", error);
      alert("שגיאה בייצוא הקובץ");
    }

    setIsCopying(false);
  };

  const handleCopyContent = async () => {
    setIsCopying(true);
    setCopySuccess(false);

    try {
      const content = `
<div dir="rtl" style="font-family: 'Arial', sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px; background-color: #ffffff;">
  <h1 style="color: #2563eb; text-align: center; font-size: 32px; margin-bottom: 10px;">${formData.site_title}</h1>
  <p style="text-align: center; color: #6b7280; font-size: 18px; margin-bottom: 30px;">${formData.site_tagline}</p>
  
  <div style="background: linear-gradient(to bottom right, #eff6ff, #f0fdf4); padding: 30px; border-radius: 12px; margin: 20px 0;">
    <h2 style="color: #1e40af; font-size: 24px; margin-bottom: 15px;">${formData.hero_title}</h2>
    <p style="color: #4b5563; font-size: 16px; line-height: 1.6;">${formData.hero_description}</p>
    <div style="margin-top: 20px; text-align: center;">
      ${formData.hero_buttons.map(button => button.url ? `
        <a href="${button.url}" style="display: inline-block; padding: 10px 20px; margin: 5px; border-radius: 8px; text-decoration: none; font-weight: bold; ${button.style === 'primary' ? 'background-color: #2563eb; color: white;' : 'background-color: #e0f2fe; color: #2563eb; border: 1px solid #2563eb;'}" target="_blank">
          ${button.text}
        </a>
      ` : '').join('')}
    </div>
  </div>

  <h2 style="color: #1e40af; margin-top: 40px; font-size: 24px;">${formData.how_it_works_title}</h2>
  <p style="color: #6b7280; margin-bottom: 20px;">${formData.how_it_works_subtitle}</p>
  
  ${formData.steps.map((step, i) => `
    <div style="background: #f8f8f8; padding: 20px; border-radius: 8px; margin: 15px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
      <h3 style="color: #2563eb; margin-bottom: 10px; font-size: 20px;">${step.title}</h3>
      <p style="color: #4b5563; line-height: 1.6; font-size: 15px;">${step.description}</p>
    </div>
  `).join('')}

  ${formData.stats && formData.stats.length > 0 ? `
    <h2 style="color: #1e40af; margin-top: 40px; font-size: 24px;">${formData.stats_title}</h2>
    <p style="color: #6b7280; margin-bottom: 20px;">${formData.stats_subtitle}</p>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0;">
      ${formData.stats.map(stat => `
        <div style="background: #f8f8f8; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
          <div style="font-size: 32px; font-weight: bold; color: #2563eb; margin-bottom: 8px;">${stat.value}</div>
          <div style="font-weight: bold; color: #1f2937; margin-bottom: 4px; font-size: 16px;">${stat.title}</div>
          <div style="font-size: 14px; color: #6b7280;">${stat.description}</div>
        </div>
      `).join('')}
    </div>
  ` : ''}

  ${formData.features && formData.features.length > 0 ? `
    <h2 style="color: #1e40af; margin-top: 40px; font-size: 24px;">${formData.features_title}</h2>
    <p style="color: #6b7280; margin-bottom: 20px;">${formData.features_subtitle}</p>
    ${formData.features.map(feature => `
      <div style="background: #f8f8f8; padding: 15px; border-radius: 8px; margin: 10px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
        <h4 style="color: #1f2937; margin-bottom: 8px; font-size: 18px;">✓ ${feature.title}</h4>
        <p style="color: #6b7280; font-size: 14px;">${feature.description}</p>
      </div>
    `).join('')}
  ` : ''}

  ${formData.show_file_info ? `
    <div style="background: #e0f2fe; padding: 25px; border-radius: 12px; margin: 20px 0; border-left: 5px solid #2563eb;">
      <h3 style="color: #1e40af; font-size: 22px; margin-bottom: 10px;">${formData.file_info_title}</h3>
      <p style="color: #4b5563; font-size: 15px; line-height: 1.6;">${formData.file_info_description}</p>
    </div>
  ` : ''}

  ${formData.show_email_alerts_info ? `
    <div style="background: #e6ffed; padding: 25px; border-radius: 12px; margin: 20px 0; border-left: 5px solid #16a34a;">
      <h3 style="color: #15803d; font-size: 22px; margin-bottom: 10px;">${formData.email_alerts_title}</h3>
      <p style="color: #4b5563; font-size: 15px; line-height: 1.6;">${formData.email_alerts_description}</p>
    </div>
  ` : ''}

  <h2 style="color: #1e40af; margin-top: 40px; font-size: 24px;">${formData.benefits_title}</h2>
  <p style="color: #6b7280; margin-bottom: 20px;">${formData.benefits_subtitle}</p>
  
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0;">
  ${formData.benefits.map(benefit => `
    <div style="background: #f8f8f8; padding: 15px; border-radius: 8px; margin: 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;">
      <div style="font-size: 28px; color: #2563eb; margin-bottom: 10px;">${benefit.icon === 'Shield' ? '🛡️' : benefit.icon === 'Clock' ? '⏰' : benefit.icon === 'Users' ? '👥' : benefit.icon === 'Heart' ? '❤️' : '⭐'}</div>
      <h4 style="color: #1f2937; margin-bottom: 8px; font-size: 18px;">${benefit.title}</h4>
      <p style="color: #6b7280; font-size: 14px;">${benefit.description}</p>
    </div>
  `).join('')}
  </div>

  <h2 style="color: #1e40af; margin-top: 40px; font-size: 24px;">${formData.actions_title}</h2>
  <p style="color: #6b7280; margin-bottom: 20px;">${formData.actions_subtitle}</p>

  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin: 20px 0;">
    ${formData.quick_actions.map(action => `
      <div style="background: #f8f8f8; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
        <h4 style="color: #1f2937; margin-bottom: 8px; font-size: 18px;">${action.title}</h4>
        <p style="color: #6b7280; font-size: 14px; margin-bottom: 15px;">${action.description}</p>
        ${action.url ? `<a href="${action.url}" style="display: inline-block; padding: 8px 15px; border-radius: 6px; text-decoration: none; font-weight: bold; background-color: ${action.color === 'blue' ? '#2563eb' : action.color === 'green' ? '#16a34a' : action.color === 'orange' ? '#f97316' : action.color === 'purple' ? '#9333ea' : '#3b82f6'}; color: white; font-size: 14px;" target="_blank">בצע פעולה</a>` : ''}
      </div>
    `).join('')}
  </div>

  <div style="background: #eff6ff; padding: 25px; border-radius: 12px; margin: 40px 0; text-align: center;">
    <h2 style="color: #1e40af; margin-bottom: 10px; font-size: 24px;">${formData.contact_title}</h2>
    <p style="color: #6b7280; margin-bottom: 15px; font-size: 16px;">${formData.contact_subtitle}</p>
    <p style="color: #2563eb; font-size: 18px; font-weight: bold;">
      <a href="mailto:${formData.contact_email}" style="color: #2563eb; text-decoration: none;">${formData.contact_email}</a>
    </p>
  </div>

  ${formData.show_email_only_option ? `
  <div style="text-align: center; color: #6b7280; font-size: 14px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
    <p><strong>${formData.email_only_title}</strong></p>
    <p>${formData.email_only_description}</p>
  </div>
  ` : ''}

  <div style="text-align: center; color: #9ca3af; font-size: 12px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
    <p>© ${new Date().getFullYear()} ${formData.site_title} - כל הזכויות שמורות</p>
  </div>
</div>
      `;

      await navigator.clipboard.writeText(content);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 5000);
    } catch (error) {
      console.error("Error copying:", error);
      alert("שגיאה בהעתקת התוכן");
    }

    setIsCopying(false);
  };

  const getBenefitIconEmoji = (icon) => {
    switch (icon) {
      case 'Shield': return '🛡️';
      case 'Clock': return '⏰';
      case 'Users': return '👥';
      case 'Heart': return '❤️';
      case 'Star': return '⭐';
      default: return '⚡';
    }
  };

  const handleExportAd = async () => {
    setIsExportingAd(true);
    setExportAdSuccess(false);

    try {
      const adContent = `
<!DOCTYPE html>
<html dir="rtl" lang="he">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>מודעה: ${formData.site_title}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #eff6ff 0%, #f0fdf4 100%);
            padding: 40px 20px;
            line-height: 1.6;
            direction: rtl;
        }
        .ad-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 24px;
            box-shadow: 0 25px 70px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .ad-header {
            background: linear-gradient(135deg, #2563eb 0%, #16a34a 100%);
            color: white;
            padding: 50px 40px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .ad-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: pulse 3s ease-in-out infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }
        .ad-badge {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.4);
            padding: 10px 25px;
            border-radius: 30px;
            margin-bottom: 20px;
            font-size: 16px;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }
        .ad-header h1 {
            font-size: 56px;
            font-weight: 900;
            margin-bottom: 15px;
            text-shadow: 3px 3px 6px rgba(0,0,0,0.3);
            position: relative;
            z-index: 1;
        }
        .ad-header .tagline {
            font-size: 26px;
            font-weight: 600;
            opacity: 0.95;
            position: relative;
            z-index: 1;
        }
        .ad-content {
            padding: 50px 40px;
        }
        .ad-intro {
            text-align: center;
            margin-bottom: 50px;
        }
        .ad-intro h2 {
            color: #1e40af;
            font-size: 38px;
            font-weight: 800;
            margin-bottom: 20px;
            line-height: 1.3;
        }
        .ad-intro p {
            color: #4b5563;
            font-size: 20px;
            line-height: 1.8;
            max-width: 700px;
            margin: 0 auto;
        }
        .benefits-section {
            margin: 50px 0;
        }
        .benefits-title {
            text-align: center;
            color: #1e40af;
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 40px;
        }
        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin-bottom: 40px;
        }
        .benefit-item {
            background: linear-gradient(135deg, #f0f9ff 0%, #f0fdf4 100%);
            padding: 30px;
            border-radius: 16px;
            border-right: 5px solid #2563eb;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s;
        }
        .benefit-item:hover {
            transform: translateY(-5px);
        }
        .benefit-item .icon {
            font-size: 42px;
            margin-bottom: 15px;
        }
        .benefit-item h3 {
            color: #1e40af;
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 12px;
        }
        .benefit-item p {
            color: #4b5563;
            font-size: 16px;
            line-height: 1.7;
        }
        .cta-section {
            background: linear-gradient(135deg, #1e40af 0%, #15803d 100%);
            padding: 50px 40px;
            border-radius: 20px;
            text-align: center;
            margin: 40px 0;
            box-shadow: 0 15px 40px rgba(37, 99, 235, 0.3);
        }
        .cta-section h2 {
            color: white;
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 20px;
        }
        .cta-section p {
            color: rgba(255,255,255,0.95);
            font-size: 20px;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .cta-button {
            display: inline-block;
            padding: 18px 40px;
            background: white;
            color: #1e40af;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 800;
            font-size: 18px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            transition: all 0.3s;
        }
        .cta-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(0,0,0,0.3);
        }
        .contact-box {
            background: #f9fafb;
            padding: 30px;
            border-radius: 16px;
            text-align: center;
            border: 2px solid #e5e7eb;
        }
        .contact-box h3 {
            color: #1e40af;
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 15px;
        }
        .contact-box p {
            color: #6b7280;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .contact-email {
            display: inline-block;
            color: #2563eb;
            font-size: 20px;
            font-weight: 700;
            text-decoration: none;
            padding: 12px 30px;
            background: white;
            border: 2px solid #2563eb;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .contact-email:hover {
            background: #2563eb;
            color: white;
        }
        .ad-footer {
            background: #1f2937;
            color: white;
            padding: 30px;
            text-align: center;
        }
        .ad-footer p {
            font-size: 14px;
            opacity: 0.8;
        }
        
        /* כללים להדפסה */
        @media print {
            body {
                padding: 0;
                background: white;
            }
            .ad-container {
                box-shadow: none;
                border-radius: 0;
                max-width: 100%;
            }
            .ad-header {
                background: #2563eb !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                page-break-after: avoid;
            }
            .ad-header::before {
                display: none;
            }
            .benefit-item {
                background: #f0f9ff !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                page-break-inside: avoid;
            }
            .cta-section {
                background: #1e40af !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                page-break-inside: avoid;
            }
            .ad-footer {
                background: #1f2937 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .cta-button, .contact-email {
                text-decoration: underline;
            }
        }
    </style>
</head>
<body>
    <div class="ad-container">
        <div class="ad-header">
            <div class="ad-badge">🎉 השקה מיוחדת 🎉</div>
            <h1>${formData.site_title}</h1>
            <div class="tagline">${formData.site_tagline}</div>
        </div>
        
        <div class="ad-content">
            <div class="ad-intro">
                <h2>${formData.hero_title}</h2>
                <p>${formData.hero_description}</p>
            </div>

            <div class="benefits-section">
                <h2 class="benefits-title">למה ${formData.site_title}?</h2>
                <div class="benefits-grid">
                    ${formData.benefits.slice(0, 4).map(benefit => `
                        <div class="benefit-item">
                            <div class="icon">${getBenefitIconEmoji(benefit.icon)}</div>
                            <h3>${benefit.title}</h3>
                            <p>${benefit.description}</p>
                        </div>
                    `).join('')}
                </div>
            </div>

            <div class="cta-section">
                <h2>הצטרפו אלינו עכשיו!</h2>
                <p>התחילו למצוא את הדירה המושלמת או לפרסם את הדירה שלכם<br/>בפלטפורמה הקהילתית המתקדמת ביותר</p>
                <div class="cta-buttons">
                    ${formData.register_form_url ? `
                        <a href="${formData.register_form_url}" class="cta-button" target="_blank">
                            📬 הרשמה לקבלת עדכונים על דירות
                        </a>
                    ` : ''}
                    ${formData.publish_apartment_url ? `
                        <a href="${formData.publish_apartment_url}" class="cta-button" target="_blank">
                            🏠 פרסום דירה חדשה
                        </a>
                    ` : ''}
                </div>
            </div>

            <div class="contact-box">
                <h3>יש לכם שאלות?</h3>
                <p>נשמח לספר לכם עוד על המערכת ולעזור לכם להתחיל</p>
                <a href="mailto:${formData.contact_email}" class="contact-email">${formData.contact_email}</a>
            </div>
        </div>

        <div class="ad-footer">
            <p>© ${new Date().getFullYear()} ${formData.site_title} - מחברים בין מחפשי דירות למפרסמים</p>
        </div>
    </div>
</body>
</html>
      `;

      const blob = new Blob([adContent], { type: 'text/html;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `מודעת_פרסום_${formData.site_title}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      setExportAdSuccess(true);
      setTimeout(() => setExportAdSuccess(false), 5000);
    } catch (error) {
      console.error("Error exporting ad:", error);
      alert("שגיאה בייצוא המודעה");
    }

    setIsExportingAd(false);
  };

  const handleCopyAd = async () => {
    setIsCopyingAd(true);
    setCopyAdSuccess(false);

    try {
      const adEmailContent = `
<div dir="rtl" style="font-family: 'Arial', sans-serif; max-width: 700px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.15);">
  <!-- Header -->
  <div style="background: linear-gradient(135deg, #2563eb 0%, #16a34a 100%); color: white; padding: 40px 30px; text-align: center;">
    <div style="display: inline-block; background: rgba(255,255,255,0.2); border: 2px solid rgba(255,255,255,0.4); padding: 8px 20px; border-radius: 25px; margin-bottom: 15px; font-size: 14px; font-weight: 700;">
      🎉 השקה מיוחדת 🎉
    </div>
    <h1 style="font-size: 42px; font-weight: 900; margin: 0 0 10px 0; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">${formData.site_title}</h1>
    <p style="font-size: 20px; font-weight: 600; margin: 0; opacity: 0.95;">${formData.site_tagline}</p>
  </div>

  <!-- Content -->
  <div style="padding: 40px 30px;">
    <!-- Intro -->
    <div style="text-align: center; margin-bottom: 40px;">
      <h2 style="color: #1e40af; font-size: 32px; font-weight: 800; margin: 0 0 15px 0; line-height: 1.3;">${formData.hero_title}</h2>
      <p style="color: #4b5563; font-size: 18px; line-height: 1.7; margin: 0;">${formData.hero_description}</p>
    </div>

    <!-- Benefits -->
    <h2 style="text-align: center; color: #1e40af; font-size: 28px; font-weight: 800; margin: 0 0 30px 0;">למה ${formData.site_title}?</h2>
    
    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 30px;">
      <tr>
        ${formData.benefits.slice(0, 2).map(benefit => `
          <td width="48%" style="vertical-align: top; padding: 0 1%;">
            <div style="background: linear-gradient(135deg, #f0f9ff 0%, #f0fdf4 100%); padding: 25px; border-radius: 12px; border-right: 4px solid #2563eb; margin-bottom: 15px;">
              <div style="font-size: 36px; margin-bottom: 10px;">${getBenefitIconEmoji(benefit.icon)}</div>
              <h3 style="color: #1e40af; font-size: 20px; font-weight: 700; margin: 0 0 10px 0;">${benefit.title}</h3>
              <p style="color: #4b5563; font-size: 15px; line-height: 1.6; margin: 0;">${benefit.description}</p>
            </div>
          </td>
        `).join('')}
      </tr>
      ${formData.benefits.length > 2 ? `
      <tr>
        ${formData.benefits.slice(2, 4).map(benefit => `
          <td width="48%" style="vertical-align: top; padding: 0 1%;">
            <div style="background: linear-gradient(135deg, #f0f9ff 0%, #f0fdf4 100%); padding: 25px; border-radius: 12px; border-right: 4px solid #2563eb;">
              <div style="font-size: 36px; margin-bottom: 10px;">${getBenefitIconEmoji(benefit.icon)}</div>
              <h3 style="color: #1e40af; font-size: 20px; font-weight: 700; margin: 0 0 10px 0;">${benefit.title}</h3>
              <p style="color: #4b5563; font-size: 15px; line-height: 1.6; margin: 0;">${benefit.description}</p>
            </div>
          </td>
        `).join('')}
      </tr>
      ` : ''}
    </table>

    <!-- CTA -->
    <div style="background: linear-gradient(135deg, #1e40af 0%, #15803d 100%); padding: 40px 30px; border-radius: 16px; text-align: center; margin: 30px 0;">
      <h2 style="color: white; font-size: 32px; font-weight: 800; margin: 0 0 15px 0;">הצטרפו אלינו עכשיו!</h2>
      <p style="color: rgba(255,255,255,0.95); font-size: 18px; margin: 0 0 25px 0; line-height: 1.6;">התחילו למצוא את הדירה המושלמת או לפרסם את הדירה שלכם<br/>בפלטפורמה הקהילתית המתקדמת ביותר</p>
      <div style="text-align: center;">
        ${formData.register_form_url ? `
          <a href="${formData.register_form_url}" style="display: inline-block; margin: 5px 10px; padding: 15px 35px; background: white; color: #1e40af; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 17px;" target="_blank">
            📬 הרשמה לקבלת עדכונים על דירות
          </a>
        ` : ''}
        ${formData.publish_apartment_url ? `
          <a href="${formData.publish_apartment_url}" style="display: inline-block; margin: 5px 10px; padding: 15px 35px; background: white; color: #1e40af; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 17px;" target="_blank">
            🏠 פרסום דירה חדשה
          </a>
        ` : ''}
      </div>
    </div>

    <!-- Contact -->
    <div style="background: #f9fafb; padding: 25px; border-radius: 12px; text-align: center; border: 2px solid #e5e7eb;">
      <h3 style="color: #1e40af; font-size: 22px; font-weight: 700; margin: 0 0 12px 0;">יש לכם שאלות?</h3>
      <p style="color: #6b7280; font-size: 15px; margin: 0 0 15px 0;">נשמח לספר לכם עוד על המערכת ולעזור לכם להתחיל</p>
      <a href="mailto:${formData.contact_email}" style="display: inline-block; color: #2563eb; font-size: 18px; font-weight: 700; text-decoration: none; padding: 10px 25px; background: white; border: 2px solid #2563eb; border-radius: 8px;">${formData.contact_email}</a>
    </div>
  </div>

  <!-- Footer -->
  <div style="background: #1f2937; color: white; padding: 25px; text-align: center;">
    <p style="font-size: 13px; opacity: 0.8; margin: 0;">© ${new Date().getFullYear()} ${formData.site_title} - מחברים בין מחפשי דירות למפרסמים</p>
  </div>
</div>
      `;

      await navigator.clipboard.writeText(adEmailContent);
      setCopyAdSuccess(true);
      setTimeout(() => setCopyAdSuccess(false), 5000);
    } catch (error) {
      console.error("Error copying ad:", error);
      alert("שגיאה בהעתקת המודעה");
    }

    setIsCopyingAd(false);
  };

  if (loading || settingsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-gray-50 flex items-center justify-center" dir="rtl">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-gray-50 p-6" dir="rtl">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <SettingsIcon className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">הגדרות מערכת</h1>
          </div>
          <p className="text-gray-600 mr-15">ניהול תוכן ומראה האתר</p>
        </motion.div>

        <Card className="border-none shadow-xl">
          <CardContent className="p-6">
            <Tabs defaultValue="forms" dir="rtl">
              <TabsList className="grid w-full grid-cols-4 mb-6">
                <TabsTrigger value="forms">קישורי טפסים</TabsTrigger>
                <TabsTrigger value="content">
                  <Type className="w-4 h-4 ml-2" />
                  תוכן האתר
                </TabsTrigger>
                <TabsTrigger value="contact">
                  <Mail className="w-4 h-4 ml-2" />
                  צור קשר
                </TabsTrigger>
                <TabsTrigger value="export">
                  <ExternalLink className="w-4 h-4 ml-2" />
                  שיתוף וייצוא
                </TabsTrigger>
              </TabsList>

              <form onSubmit={handleSubmit} className="space-y-6">
                <TabsContent value="forms" className="space-y-6 mt-0">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">קישורי Google Forms</h3>
                    <p className="text-sm text-gray-600 mb-6">
                      הזינו את הקישורים לטפסים. הקישורים האלה ישמשו בכפתורים באתר.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      טופס הרשמה לקבלת עדכונים
                    </label>
                    <div className="flex gap-2">
                      <Input
                        value={formData.register_form_url}
                        onChange={(e) => setFormData({ ...formData, register_form_url: e.target.value })}
                        placeholder="https://forms.google.com/..."
                        className="flex-1"
                      />
                      {formData.register_form_url && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => window.open(formData.register_form_url, '_blank')}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      טופס הפסקת קבלת עדכונים
                    </label>
                    <div className="flex gap-2">
                      <Input
                        value={formData.unregister_form_url}
                        onChange={(e) => setFormData({ ...formData, unregister_form_url: e.target.value })}
                        placeholder="https://forms.google.com/..."
                        className="flex-1"
                      />
                      {formData.unregister_form_url && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => window.open(formData.unregister_form_url, '_blank')}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      טופס פרסום דירה
                    </label>
                    <div className="flex gap-2">
                      <Input
                        value={formData.publish_apartment_url}
                        onChange={(e) => setFormData({ ...formData, publish_apartment_url: e.target.value })}
                        placeholder="https://forms.google.com/..."
                        className="flex-1"
                      />
                      {formData.publish_apartment_url && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => window.open(formData.publish_apartment_url, '_blank')}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      טופס הסרת דירה
                    </label>
                    <div className="flex gap-2">
                      <Input
                        value={formData.remove_apartment_url}
                        onChange={(e) => setFormData({ ...formData, remove_apartment_url: e.target.value })}
                        placeholder="https://forms.google.com/..."
                        className="flex-1"
                      />
                      {formData.remove_apartment_url && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => window.open(formData.remove_apartment_url, '_blank')}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="border-t pt-6 mt-6">
                    <h3 className="text-lg font-semibold mb-4">קובץ דוגמה למנויים</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      קישור לקובץ/מסמך לדוגמה שמראה למתעניינים איך ייראה המייל או הקובץ שהם יקבלו עם הדירות המתאימות
                    </p>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        קישור לקובץ דוגמה
                      </label>
                      <div className="flex gap-2">
                        <Input
                          value={formData.example_file_url}
                          onChange={(e) => setFormData({ ...formData, example_file_url: e.target.value })}
                          placeholder="https://drive.google.com/... או https://..."
                          className="flex-1"
                        />
                        {formData.example_file_url && (
                          <Button
                            type="button"
                            variant="outline"
                            size="icon"
                            onClick={() => window.open(formData.example_file_url, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        מומלץ: Google Doc, PDF או קישור לתמונה
                      </p>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="content" className="space-y-8 mt-0">
                  {/* מידע כללי */}
                  <div className="border-b pb-6">
                    <h3 className="text-lg font-semibold mb-4">מידע כללי</h3>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          שם האתר
                        </label>
                        <Input
                          value={formData.site_title}
                          onChange={(e) => setFormData({ ...formData, site_title: e.target.value })}
                          placeholder="שיתופים"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          סלוגן האתר
                        </label>
                        <Input
                          value={formData.site_tagline}
                          onChange={(e) => setFormData({ ...formData, site_tagline: e.target.value })}
                          placeholder="לוח דירות חכם"
                        />
                      </div>
                    </div>
                  </div>

                  {/* סקשן ראשי */}
                  <div className="border-b pb-6">
                    <h3 className="text-lg font-semibold mb-4">סקשן ראשי (Hero)</h3>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תווית (Badge)
                        </label>
                        <Input
                          value={formData.hero_badge}
                          onChange={(e) => setFormData({ ...formData, hero_badge: e.target.value })}
                          placeholder="לוח דירות חכם וקהילתי"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת ראשית
                        </label>
                        <Input
                          value={formData.hero_title}
                          onChange={(e) => setFormData({ ...formData, hero_title: e.target.value })}
                          placeholder="מוצאים דירה ביחד, בקלות ובפשטות"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תיאור
                        </label>
                        <Textarea
                          value={formData.hero_description}
                          onChange={(e) => setFormData({ ...formData, hero_description: e.target.value })}
                          placeholder="פלטפורמה קהילתית ייחודית..."
                          className="min-h-[80px]"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          כפתורים
                        </label>
                        <DynamicList
                          items={formData.hero_buttons}
                          onChange={(items) => setFormData({ ...formData, hero_buttons: items })}
                          type="button"
                        />
                      </div>
                    </div>
                  </div>

                  {/* איך זה עובד */}
                  <div className="border-b pb-6">
                    <h3 className="text-lg font-semibold mb-4">סקשן "איך זה עובד"</h3>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.how_it_works_title}
                          onChange={(e) => setFormData({ ...formData, how_it_works_title: e.target.value })}
                          placeholder="איך זה עובד?"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תת כותרת
                        </label>
                        <Input
                          value={formData.how_it_works_subtitle}
                          onChange={(e) => setFormData({ ...formData, how_it_works_subtitle: e.target.value })}
                          placeholder="תהליך פשוט ומהיר בשלושה שלבים"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          שלבים
                        </label>
                        <DynamicList
                          items={formData.steps}
                          onChange={(items) => setFormData({ ...formData, steps: items })}
                          type="step"
                        />
                      </div>
                    </div>
                  </div>

                  {/* סקשן מספרים */}
                  <div className="border-b pb-6">
                    <h3 className="text-lg font-semibold mb-4">סקשן "המערכת שלנו במספרים"</h3>
                    <p className="text-sm text-gray-600 mb-6">
                      הוסיפו מספרים מרשימים על המערכת (למשל: 500+ דירות, 1000+ משתמשים וכו')
                      <br />
                      <span className="font-medium">סקשן זה יוצג באתר רק אם תוסיפו לפחות פריט אחד</span>
                    </p>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.stats_title}
                          onChange={(e) => setFormData({ ...formData, stats_title: e.target.value })}
                          placeholder="המערכת שלנו במספרים"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תת כותרת
                        </label>
                        <Input
                          value={formData.stats_subtitle}
                          onChange={(e) => setFormData({ ...formData, stats_subtitle: e.target.value })}
                          placeholder="נתונים וסטטיסטיקות"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          מספרים וסטטיסטיקות
                        </label>
                        <DynamicList
                          items={formData.stats}
                          onChange={(items) => setFormData({ ...formData, stats: items })}
                          type="stat"
                        />
                        <p className="text-xs text-gray-500 mt-2">
                          דוגמאות: "500+ דירות", "1000+ משתמשים", "95% שביעות רצון" וכו'
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* סקשן פיצ'רים */}
                  <div className="border-b pb-6">
                    <h3 className="text-lg font-semibold mb-4">סקשן "פיצ'רים ויכולות"</h3>
                    <p className="text-sm text-gray-600 mb-6">
                      הוסיפו את הפיצ'רים והיכולות של המערכת (למשל: תמיכה בתמונות, עדכון יומי וכו')
                      <br />
                      <span className="font-medium">סקשן זה יוצג באתר רק אם תוסיפו לפחות פריט אחד</span>
                    </p>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.features_title}
                          onChange={(e) => setFormData({ ...formData, features_title: e.target.value })}
                          placeholder="פיצ'רים ויכולות"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תת כותרת
                        </label>
                        <Input
                          value={formData.features_subtitle}
                          onChange={(e) => setFormData({ ...formData, features_subtitle: e.target.value })}
                          placeholder="מה המערכת מציעה"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          פיצ'רים
                        </label>
                        <DynamicList
                          items={formData.features}
                          onChange={(items) => setFormData({ ...formData, features: items })}
                          type="feature"
                        />
                        <p className="text-xs text-gray-500 mt-2">
                          דוגמאות: "תמיכה בהעלאת תמונות", "עדכון יומי של דירות", "התאמה חכמה" וכו'
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* הצגת מידע על קובץ מתעדכן */}
                  <div className="border-b pb-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">מידע על מאגר הנתונים (קובץ מתעדכן)</h3>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.show_file_info}
                          onChange={(e) => setFormData({ ...formData, show_file_info: e.target.checked })}
                          className="w-4 h-4 rounded border-gray-300"
                        />
                        <span className="text-sm text-gray-600">הצג באתר</span>
                      </label>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.file_info_title}
                          onChange={(e) => setFormData({ ...formData, file_info_title: e.target.value })}
                          placeholder="מקבלים קובץ מתעדכן אונליין"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תיאור
                        </label>
                        <Textarea
                          value={formData.file_info_description}
                          onChange={(e) => setFormData({ ...formData, file_info_description: e.target.value })}
                          placeholder="כאשר נרשמים למערכת, מקבלים גישה לקובץ..."
                          className="min-h-[100px]"
                        />
                      </div>
                    </div>
                  </div>

                  {/* הצגת מידע על התראות מייל */}
                  <div className="border-b pb-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">התראות במייל</h3>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.show_email_alerts_info}
                          onChange={(e) => setFormData({ ...formData, show_email_alerts_info: e.target.checked })}
                          className="w-4 h-4 rounded border-gray-300"
                        />
                        <span className="text-sm text-gray-600">הצג באתר</span>
                      </label>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.email_alerts_title}
                          onChange={(e) => setFormData({ ...formData, email_alerts_title: e.target.value })}
                          placeholder="התראות מיידיות על דירות חדשות"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תיאור
                        </label>
                        <Textarea
                          value={formData.email_alerts_description}
                          onChange={(e) => setFormData({ ...formData, email_alerts_description: e.target.value })}
                          placeholder="בנוסף לקובץ המתעדכן, תוכלו לבחור לקבל גם התראות במייל..."
                          className="min-h-[100px]"
                        />
                      </div>
                    </div>
                  </div>

                  {/* אפשרות מייל בלבד */}
                  <div className="border-b pb-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">אפשרות מייל בלבד (עבור חסומי רשת)</h3>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.show_email_only_option}
                          onChange={(e) => setFormData({ ...formData, show_email_only_option: e.target.checked })}
                          className="w-4 h-4 rounded border-gray-300"
                        />
                        <span className="text-sm text-gray-600">הצג באתר</span>
                      </label>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.email_only_title}
                          onChange={(e) => setFormData({ ...formData, email_only_title: e.target.value })}
                          placeholder="עבור חסומי רשת - אפשרות מייל בלבד"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תיאור
                        </label>
                        <Textarea
                          value={formData.email_only_description}
                          onChange={(e) => setFormData({ ...formData, email_only_description: e.target.value })}
                          placeholder="אם אתם חסומים לרשת או מעדיפים לקבל את המידע רק במייל..."
                          className="min-h-[100px]"
                        />
                      </div>
                    </div>

                    <div className="mt-3 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                      <p className="text-xs text-gray-600">
                        💡 <strong>טיפ:</strong> מידע זה יוצג באופן עדין בתחתית דף הבית, לא במיקום בולט מדי, כדי לספק מענה לאוכלוסייה זו מבלי להסיח את תשומת הלב מהזרימה הראשית.
                      </p>
                    </div>
                  </div>

                  {/* יתרונות */}
                  <div className="border-b pb-6">
                    <h3 className="text-lg font-semibold mb-4">סקשן יתרונות</h3>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.benefits_title}
                          onChange={(e) => setFormData({ ...formData, benefits_title: e.target.value })}
                          placeholder="למה שיתופים?"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תת כותרת
                        </label>
                        <Input
                          value={formData.benefits_subtitle}
                          onChange={(e) => setFormData({ ...formData, benefits_subtitle: e.target.value })}
                          placeholder="הפלטפורמה המתקדמת והידידותית ביותר לחיפוש דירות"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          יתרונות
                        </label>
                        <DynamicList
                          items={formData.benefits}
                          onChange={(items) => setFormData({ ...formData, benefits: items })}
                          type="benefit"
                        />
                      </div>
                    </div>
                  </div>

                  {/* פעולות מהירות */}
                  <div className="border-b pb-6">
                    <h3 className="text-lg font-semibold mb-4">סקשן פעולות מהירות</h3>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.actions_title}
                          onChange={(e) => setFormData({ ...formData, actions_title: e.target.value })}
                          placeholder="פעולות מהירות"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תת כותרת
                        </label>
                        <Input
                          value={formData.actions_subtitle}
                          onChange={(e) => setFormData({ ...formData, actions_subtitle: e.target.value })}
                          placeholder="בחרו את הפעולה המתאימה עבורכם"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">
                          פעולות
                        </label>
                        <DynamicList
                          items={formData.quick_actions}
                          onChange={(items) => setFormData({ ...formData, quick_actions: items })}
                          type="action"
                        />
                      </div>
                    </div>
                  </div>

                  {/* צור קשר */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">סקשן צור קשר</h3>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          כותרת
                        </label>
                        <Input
                          value={formData.contact_title}
                          onChange={(e) => setFormData({ ...formData, contact_title: e.target.value })}
                          placeholder="יש לכם שאלות? נשמח לעזור"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          תת כותרת
                        </label>
                        <Input
                          value={formData.contact_subtitle}
                          onChange={(e) => setFormData({ ...formData, contact_subtitle: e.target.value })}
                          placeholder="צרו איתנו קשר ונחזור אליכם בהקדם"
                        />
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="contact" className="space-y-6 mt-0">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">הגדרות צור קשר</h3>
                    <p className="text-sm text-gray-600 mb-6">
                      הגדירו את כתובת המייל שאליה יישלחו פניות מטופס יצירת הקשר באתר
                    </p>
                  </div>

                  <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6">
                    <div className="flex items-start gap-4 mb-6">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Mail className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900 mb-2">כתובת מייל לקבלת פניות</h4>
                        <p className="text-sm text-gray-600 mb-4">
                          כל הפניות שמגיעות דרך טופס "צור קשר" באתר יישלחו לכתובת מייל זו
                        </p>
                        <Input
                          type="email"
                          value={formData.contact_email}
                          onChange={(e) => setFormData({ ...formData, contact_email: e.target.value })}
                          placeholder="contact@example.com"
                          className="text-lg"
                          required
                        />
                        <p className="text-xs text-gray-500 mt-2">
                          <strong>חשוב:</strong> ודאו שכתובת המייל פעילה ונבדקת באופן קבוע
                        </p>
                      </div>
                    </div>

                    <div className="bg-white border border-blue-200 rounded-lg p-4">
                      <h5 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-blue-600" />
                        היכן נעשה שימוש בכתובת זו?
                      </h5>
                      <ul className="text-sm text-gray-700 space-y-1">
                        <li>• <strong>באתר:</strong> טופס יצירת קשר בדף הבית</li>
                        <li>• <strong>בייצוא HTML:</strong> כתובת המייל תוצג במסמך המלא</li>
                        <li>• <strong>במודעת הפרסום:</strong> כתובת המייל תוצג למעוניינים ליצור קשר</li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <p className="text-sm text-green-800">
                      💡 <strong>טיפ:</strong> מומלץ להשתמש בכתובת מייל ייעודית למערכת, כך תוכלו לעקוב בקלות אחר כל הפניות.
                    </p>
                  </div>
                </TabsContent>

                <TabsContent value="export" className="space-y-6 mt-0">
                  <div>
                    <h3 className="text-lg font-semibold mb-2">שיתוף תוכן האתר</h3>
                    <p className="text-sm text-gray-600 mb-6">
                      שתפו את מידע האתר עם אנשים שאין להם גישה לאתר - ייצוא לקובץ או העתקת תוכן מעוצב
                    </p>
                  </div>

                  {/* מודעת פרסום ראשונית */}
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200 rounded-xl p-6 mb-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="text-3xl">🎉</div>
                      <div>
                        <h3 className="text-xl font-bold text-purple-900">מודעת פרסום ראשונית</h3>
                        <p className="text-sm text-purple-700">מודעה מושכת להכרת המערכת לציבור הרחב</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4 mt-4">
                      <Card className="border-purple-200">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center flex-shrink-0">
                              <FileText className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-gray-900 mb-1 text-sm">ייצוא מודעה</h4>
                              <p className="text-xs text-gray-600 mb-3">הורידו קובץ HTML מעוצב של המודעה</p>
                              <Button
                                type="button"
                                onClick={handleExportAd}
                                disabled={isExportingAd}
                                size="sm"
                                className="w-full bg-gradient-to-l from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                              >
                                {isExportingAd ? (
                                  <>
                                    <Loader2 className="w-3 h-3 ml-2 animate-spin" />
                                    מייצא...
                                  </>
                                ) : (
                                  <>
                                    <FileText className="w-3 h-3 ml-2" />
                                    הורדת מודעה
                                  </>
                                )}
                              </Button>
                              {exportAdSuccess && (
                                <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded text-xs">
                                  <p className="text-green-700 font-medium">✓ המודעה הורדה!</p>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="border-purple-200">
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                              <Mail className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-gray-900 mb-1 text-sm">העתקה למייל</h4>
                              <p className="text-xs text-gray-600 mb-3">העתיקו את המודעה לשליחה במייל</p>
                              <Button
                                type="button"
                                onClick={handleCopyAd}
                                disabled={isCopyingAd}
                                size="sm"
                                className="w-full bg-gradient-to-l from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
                              >
                                {isCopyingAd ? (
                                  <>
                                    <Loader2 className="w-3 h-3 ml-2 animate-spin" />
                                    מעתיק...
                                  </>
                                ) : (
                                  <>
                                    <Mail className="w-3 h-3 ml-2" />
                                    העתק מודעה
                                  </>
                                )}
                              </Button>
                              {copyAdSuccess && (
                                <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded text-xs">
                                  <p className="text-green-700 font-medium">✓ הועתק למייל!</p>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="mt-4 bg-purple-100 border border-purple-200 rounded-lg p-3">
                      <p className="text-xs text-purple-800">
                        <strong>💡 טיפ:</strong> המודעה מכילה את היתרונות המרכזיים וקריאה לפעולה - מושלם לשיתוף ברשתות חברתיות, קבוצות ווטסאפ, או רשימות תפוצה!
                      </p>
                    </div>
                  </div>

                  {/* תוכן מלא של הא באתר */}
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-4">תוכן מלא של האתר</h4>
                    
                    {/* ייצוא ל-HTML/PDF */}
                    <Card className="border-2 border-blue-100 mb-4">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                            <FileText className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-bold text-gray-900 mb-2">ייצוא מסמך HTML מקצועי</h4>
                            <p className="text-sm text-gray-600 mb-4">
                              הורידו קובץ HTML מעוצב לחלוטין שנראה בדיוק כמו האתר שלכם. 
                              <br />
                              <strong>להמרה ל-PDF:</strong> פתחו את הקובץ בדפדפן ולחצו Ctrl+P (או Cmd+P במק) ← "שמירה כ-PDF"
                            </p>
                            <Button
                              type="button"
                              onClick={handleExportPDF}
                              disabled={isExporting}
                              className="bg-gradient-to-l from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                            >
                              {isExporting ? (
                                <>
                                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                                  מייצא...
                                </>
                              ) : (
                                <>
                                  <FileText className="w-4 h-4 ml-2" />
                                  הורדת מסמך HTML
                                </>
                              )}
                            </Button>
                            {exportSuccess && (
                              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                                <p className="text-green-700 text-sm font-medium">
                                  ✓ הקובץ הורד בהצלחה!
                                </p>
                                <p className="text-green-600 text-xs mt-1">
                                  פתחו את הקובץ בדפדפן ולחצו Ctrl+P כדי לשמור כ-PDF
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* העתקת תוכן מעוצב */}
                    <Card className="border-2 border-green-100">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Mail className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-bold text-gray-900 mb-2">העתקת תוכן מעוצב</h4>
                            <p className="text-sm text-gray-600 mb-4">
                              העתיקו את כל תוכן האתר בפורמט HTML מעוצב - מושלם לשליחה במייל או להדבקה במסמכים
                            </p>
                            <Button
                              type="button"
                              onClick={handleCopyContent}
                              disabled={isCopying}
                              className="bg-gradient-to-l from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 w-full"
                            >
                              {isCopying ? (
                                <>
                                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                                  מעתיק...
                                </>
                              ) : (
                                <>
                                  <Mail className="w-4 h-4 ml-2" />
                                  העתק תוכן מעוצב
                                </>
                              )}
                            </Button>
                            {copySuccess && (
                              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                                <p className="text-green-700 text-sm font-medium">
                                  ✓ התוכן הועתק ללוח!
                                </p>
                                <p className="text-green-600 text-xs mt-1">
                                  כעת תוכלו להדביק אותו בגוף המייל (Ctrl+V). המייל יישלח עם העיצוב המלא
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h5 className="font-semibold text-blue-900 mb-2">💡 טיפים לשיתוף:</h5>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• <strong>למייל:</strong> העתיקו את התוכן והדביקו ישירות בגוף המייל (לא כקובץ מצורף)</li>
                      <li>• <strong>ל-PDF:</strong> הורידו את קובץ ה-HTML, פתחו בדפדפן, והדפיסו ל-PDF</li>
                      <li>• <strong>למסמכים:</strong> ניתן להדביק את התוכן ב-Google Docs או Word</li>
                      <li>• <strong>למודעה:</strong> השתמשו במודעת הפרסום הראשונית לחשיפה ראשונה של המערכת</li>
                      <li>• וודאו לשמור שינויים בהגדרות לפני הייצוא</li>
                    </ul>
                  </div>
                </TabsContent>

                <Button
                  type="submit"
                  disabled={saveMutation.isPending}
                  className="w-full bg-gradient-to-l from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                >
                  {saveMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      שומר...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 ml-2" />
                      שמירת הגדרות
                    </>
                  )}
                </Button>

                {saveMutation.isSuccess && (
                  <p className="text-center text-green-600 text-sm">
                    ההגדרות נשמרו בהצלחה!
                  </p>
                )}
              </form>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
