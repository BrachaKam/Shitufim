

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "./utils";
import { base44 } from "@/api/base44Client";
import { Home as HomeIcon, Settings as SettingsIcon, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // טעינת הגדרות לטקסטים
  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list();
      return list[0] || null;
    },
    initialData: null
  });

  const texts = {
    siteTitle: settings?.site_title || "שיתופים",
    siteTagline: settings?.site_tagline || "לוח דירות חכם"
  };

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        setUser(null);
      }
      setLoading(false);
    };
    loadUser();
  }, []);

  const isAdmin = user?.role === 'admin';

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-green-500 rounded-xl flex items-center justify-center shadow-lg">
                <HomeIcon className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-l from-blue-600 to-green-600 bg-clip-text text-transparent">
                  {texts.siteTitle}
                </h1>
                <p className="text-xs text-gray-500">{texts.siteTagline}</p>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-2">
              <Link to={createPageUrl("Home")}>
                <Button
                  variant={currentPageName === "Home" ? "default" : "ghost"}
                  className={currentPageName === "Home" ? "bg-gradient-to-l from-blue-600 to-blue-700" : ""}
                >
                  <HomeIcon className="w-4 h-4 ml-2" />
                  בית
                </Button>
              </Link>

              {isAdmin && (
                <Link to={createPageUrl("Settings")}>
                  <Button
                    variant={currentPageName === "Settings" ? "default" : "ghost"}
                    className={currentPageName === "Settings" ? "bg-gradient-to-l from-blue-600 to-blue-700" : ""}
                  >
                    <SettingsIcon className="w-4 h-4 ml-2" />
                    הגדרות
                  </Button>
                </Link>
              )}
            </nav>

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 text-gray-700" />
              ) : (
                <Menu className="w-6 h-6 text-gray-700" />
              )}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 space-y-2">
              <Link to={createPageUrl("Home")} onClick={() => setMobileMenuOpen(false)}>
                <Button
                  variant={currentPageName === "Home" ? "default" : "ghost"}
                  className={`w-full justify-start ${currentPageName === "Home" ? "bg-gradient-to-l from-blue-600 to-blue-700" : ""}`}
                >
                  <HomeIcon className="w-4 h-4 ml-2" />
                  בית
                </Button>
              </Link>

              {isAdmin && (
                <Link to={createPageUrl("Settings")} onClick={() => setMobileMenuOpen(false)}>
                  <Button
                    variant={currentPageName === "Settings" ? "default" : "ghost"}
                    className={`w-full justify-start ${currentPageName === "Settings" ? "bg-gradient-to-l from-blue-600 to-blue-700" : ""}`}
                  >
                    <SettingsIcon className="w-4 h-4 ml-2" />
                    הגדרות
                  </Button>
                </Link>
              )}
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>
        {children}
      </main>
    </div>
  );
}

