
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Home as HomeIcon,
  Users,
  Shield,
  Clock,
  CheckCircle,
  Mail,
  ExternalLink,
  Heart,
  Search,
  Bell,
  FileText,
  Star,
  Zap,
  TrendingUp
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSending, setIsSending] = useState(false);
  const [sent, setSent] = useState(false);

  // טעינת הגדרות מהמערכת
  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list();
      return list[0] || null;
    },
    initialData: null
  });

  // מיפוי אייקונים
  const iconMap = {
    shield: Shield,
    clock: Clock,
    users: Users,
    heart: Heart,
    star: Star,
    zap: Zap,
    trendingup: TrendingUp // Added TrendingUp icon
  };

  // מיפוי צבעים
  const colorMap = {
    blue: { color: "from-blue-600 to-blue-700", hover: "hover:from-blue-700 hover:to-blue-800" },
    green: { color: "from-green-600 to-green-700", hover: "hover:from-green-700 hover:to-green-800" },
    orange: { color: "from-orange-600 to-orange-700", hover: "hover:from-orange-700 hover:to-orange-800" },
    purple: { color: "from-purple-600 to-purple-700", hover: "hover:from-purple-700 hover:to-purple-800" },
    pink: { color: "from-pink-600 to-pink-700", hover: "hover:from-pink-700 hover:to-pink-800" },
    red: { color: "from-red-600 to-red-700", hover: "hover:from-red-700 hover:to-red-800" }
  };

  const texts = {
    siteTitle: settings?.site_title || "שיתופים",
    siteTagline: settings?.site_tagline || "לוח דירות חכם",
    heroBadge: settings?.hero_badge || "לוח דירות חכם וקהילתי",
    heroTitle: settings?.hero_title || "מוצאים דירה ביחד, בקלות ובפשטות",
    heroDescription: settings?.hero_description || "פלטפורמה קהילתית ייחודית שמחברת בין מחפשי דירות למפרסמים, עם התאמה אישית מלאה לצרכים שלכם",
    heroButtons: settings?.hero_buttons || [
      { text: "הרשמה לקבלת עדכונים", url: "", style: "primary" },
      { text: "פרסום דירה", url: "", style: "secondary" }
    ],
    howItWorksTitle: settings?.how_it_works_title || "איך זה עובד?",
    howItWorksSubtitle: settings?.how_it_works_subtitle || "תהליך פשוט ומהיר בשלושה שלבים",
    steps: settings?.steps || [
      { title: "1. מפרסמים מוסיפים דירות", description: "בעלי דירות ממלאים טופס פשוט" },
      { title: "2. מתעניינים נרשמים לעדכונים", description: "מחפשי דירות מגדירים את העדפותיהם" },
      { title: "3. מקבלים התאמות מושלמות", description: "המערכת שולחת דירות מתאימות" }
    ],
    statsTitle: settings?.stats_title || "המערכת שלנו במספרים",
    statsSubtitle: settings?.stats_subtitle || "נתונים וסטטיסטיקות",
    stats: settings?.stats || [],
    featuresTitle: settings?.features_title || "פיצ'רים ויכולות",
    featuresSubtitle: settings?.features_subtitle || "מה המערכת מציעה",
    features: settings?.features || [],
    showFileInfo: settings?.show_file_info !== false,
    fileInfoTitle: settings?.file_info_title || "מקבלים קובץ מתעדכן אונליין",
    fileInfoDescription: settings?.file_info_description || "כאשר נרשמים למערכת, מקבלים גישה לקובץ Google Sheets שמתעדכן אוטומטית בזמן אמת עם כל הדירות המתאימות להעדפות שלכם - מיקום, תקציב, מספר חדרים ועוד. הקובץ נשאר תמיד מעודכן ונגיש מכל מקום!",
    showEmailAlertsInfo: settings?.show_email_alerts_info !== false,
    emailAlertsTitle: settings?.email_alerts_title || "התראות מיידיות על דירות חדשות",
    emailAlertsDescription: settings?.email_alerts_description || "בנוסף לקובץ המתעדכן, תוכלו לבחור לקבל גם התראות במייל כשנוספת דירה חדשה שמתאימה בדיוק להעדפות שלכם - כך לא תפספסו אף הזדמנות!",
    showEmailOnlyOption: settings?.show_email_only_option !== false,
    emailOnlyTitle: settings?.email_only_title || "עבור חסומי רשת - אפשרות מייל בלבד",
    emailOnlyDescription: settings?.email_only_description || "אם אתם חסומים לרשת או מעדיפים לקבל את המידע רק במייל ללא גישה לקובץ אונליין, ציינו זאת בטופס ההרשמה ונתאים לכם פתרון מותאם אישית.",
    benefitsTitle: settings?.benefits_title || "למה שיתופים?",
    benefitsSubtitle: settings?.benefits_subtitle || "הפלטפורמה המתקדמת והידידותית ביותר לחיפוש דירות",
    benefits: settings?.benefits || [
      { title: "מתקדם וחכם", description: "פיצ'רים חכמים למקסימום נוחות", icon: "shield" },
      { title: "חוסך זמן", description: "רק דירות שמתאימות לכם בדיוק", icon: "clock" }
    ],
    actionsTitle: settings?.actions_title || "פעולות מהירות",
    actionsSubtitle: settings?.actions_subtitle || "בחרו את הפעולה המתאימה עבורכם",
    quickActions: settings?.quick_actions || [
      { title: "הרשמה לקבלת עדכונים", description: "קבלו התראות על דירות", url: "", color: "blue" }
    ],
    contactTitle: settings?.contact_title || "יש לכם שאלות? נשמח לעזור",
    contactSubtitle: settings?.contact_subtitle || "צרו איתנו קשר ונחזור אליכם בהקדם",
    contactEmail: settings?.contact_email || "contact@example.com"
  };

  const handleContactSubmit = async (e) => {
    e.preventDefault();
    setIsSending(true);

    try {
      await base44.integrations.Core.SendEmail({
        to: texts.contactEmail,
        subject: `הודעה חדשה מ-${contactForm.name}`,
        body: `
שם: ${contactForm.name}
דוא"ל: ${contactForm.email}

הודעה:
${contactForm.message}
        `
      });

      setSent(true);
      setContactForm({ name: "", email: "", message: "" });

      setTimeout(() => setSent(false), 5000);
    } catch (error) {
      console.error("Error sending email:", error);
    }

    setIsSending(false);
  };

  const fadeInUp = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0 }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const scaleIn = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  const heroTitleParts = texts.heroTitle.split(',');
  const stepIcons = [FileText, Bell, Search];

  const statIconMap = {
    home: HomeIcon,
    users: Users,
    trending: CheckCircle, // This can be replaced with TrendingUp if desired for stats
    check: CheckCircle,
    star: Star,
    heart: Heart
  };

  const featureIconMap = {
    image: FileText,
    database: Shield,
    clock: Clock,
    shield: Shield,
    zap: Zap,
    bell: Bell
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-green-50" dir="rtl">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-bl from-blue-100/50 via-transparent to-green-100/50" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32 relative">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="text-center"
          >
            <motion.div 
              variants={scaleIn}
              className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-full px-4 py-2 mb-6"
            >
              <Heart className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">{texts.heroBadge}</span>
            </motion.div>

            <motion.h2 
              variants={fadeInUp}
              className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight"
            >
              {heroTitleParts[0]}{heroTitleParts.length > 1 && ','}
              <br />
              <span className="bg-gradient-to-l from-blue-600 to-green-600 bg-clip-text text-transparent">
                {heroTitleParts.length > 1 ? heroTitleParts.slice(1).join(',').trim() : ''}
              </span>
            </motion.h2>

            <motion.p 
              variants={fadeInUp}
              className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed"
            >
              {texts.heroDescription}
            </motion.p>

            <motion.div 
              variants={fadeInUp}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center flex-wrap"
            >
              {texts.heroButtons.map((button, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    size="lg"
                    variant={button.style === "secondary" ? "outline" : "default"}
                    className={
                      button.style === "primary"
                        ? "bg-gradient-to-l from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all"
                        : "border-2 border-green-600 text-green-700 hover:bg-green-50 text-lg px-8 py-6"
                    }
                    onClick={() => button.url && window.open(button.url, '_blank')}
                  >
                    {button.style === "primary" ? <Users className="w-5 h-5 ml-2" /> : <FileText className="w-5 h-5 ml-2" />}
                    {button.text}
                    <ExternalLink className="w-4 h-4 mr-2" />
                  </Button>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>

        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.3, 0.2]
          }}
          transition={{ 
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-20 left-10 w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl"
        />
        <motion.div 
          animate={{ 
            scale: [1, 1.3, 1],
            opacity: [0.2, 0.25, 0.2]
          }}
          transition={{ 
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
          className="absolute bottom-20 right-10 w-72 h-72 bg-green-200 rounded-full mix-blend-multiply filter blur-3xl"
        />
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {texts.howItWorksTitle}
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              {texts.howItWorksSubtitle}
            </p>
          </motion.div>

          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-3 gap-8"
          >
            {texts.steps.map((step, index) => {
              const StepIcon = stepIcons[index % stepIcons.length];
              const colors = ["from-blue-500 to-blue-600", "from-green-500 to-green-600", "from-purple-500 to-purple-600"];

              return (
                <motion.div
                  key={index}
                  variants={fadeInUp}
                >
                  <motion.div
                    whileHover={{ y: -8, boxShadow: "0 20px 40px rgba(0,0,0,0.15)" }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Card className="h-full border-none shadow-lg transition-all duration-300">
                      <CardContent className="p-8">
                        <motion.div 
                          className={`w-16 h-16 bg-gradient-to-br ${colors[index % colors.length]} rounded-2xl flex items-center justify-center mb-6 shadow-lg`}
                          whileHover={{ rotate: 360, scale: 1.1 }}
                          transition={{ duration: 0.6 }}
                        >
                          <StepIcon className="w-8 h-8 text-white" />
                        </motion.div>
                        <h4 className="text-xl font-bold text-gray-900 mb-3">
                          {step.title}
                        </h4>
                        <p className="text-gray-600 leading-relaxed">
                          {step.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              );
            })}
          </motion.div>

          {settings?.example_file_url && (
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={scaleIn}
              className="text-center mt-12"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => window.open(settings.example_file_url, '_blank')}
                  className="border-2 border-blue-600 text-blue-700 hover:bg-blue-50"
                >
                  <FileText className="w-5 h-5 ml-2" />
                  ראו דוגמה של מה תקבלו
                  <ExternalLink className="w-4 h-4 mr-2" />
                </Button>
              </motion.div>
            </motion.div>
          )}
        </div>
      </section>

      {/* File Info Section */}
      {texts.showFileInfo && (
        <section className="py-20 bg-gradient-to-b from-white to-blue-50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={scaleIn}
            >
              <motion.div
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 to-green-50">
                  <CardContent className="p-8 md:p-12">
                    <div className="flex items-start gap-6">
                      <motion.div 
                        className="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg"
                        animate={{ 
                          rotate: [0, 5, -5, 0],
                          scale: [1, 1.05, 1]
                        }}
                        transition={{ 
                          duration: 3,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      >
                        <FileText className="w-8 h-8 text-white" />
                      </motion.div>
                      <div className="flex-1">
                        <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                          {texts.fileInfoTitle}
                        </h3>
                        <p className="text-lg text-gray-700 leading-relaxed">
                          {texts.fileInfoDescription}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </div>
        </section>
      )}

      {/* Email Alerts Info Section */}
      {texts.showEmailAlertsInfo && (
        <section className="py-20 bg-white">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={scaleIn}
            >
              <motion.div
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Card className="border-none shadow-xl bg-gradient-to-br from-green-50 to-blue-50">
                  <CardContent className="p-8 md:p-12">
                    <div className="flex items-start gap-6">
                      <motion.div 
                        className="w-16 h-16 bg-gradient-to-br from-green-500 to-blue-500 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg"
                        animate={{ 
                          y: [0, -5, 0]
                        }}
                        transition={{ 
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      >
                        <Bell className="w-8 h-8 text-white" />
                      </motion.div>
                      <div className="flex-1">
                        <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                          {texts.emailAlertsTitle}
                        </h3>
                        <p className="text-lg text-gray-700 leading-relaxed">
                          {texts.emailAlertsDescription}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </div>
        </section>
      )}

      {/* Stats - המערכת שלנו במספרים */}
      {texts.stats && texts.stats.length > 0 && (
        <section className="py-20 bg-gradient-to-b from-white to-blue-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={fadeInUp}
              className="text-center mb-16"
            >
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                {texts.statsTitle}
              </h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {texts.statsSubtitle}
              </p>
            </motion.div>

            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={staggerContainer}
              className="grid grid-cols-2 md:grid-cols-4 gap-6"
            >
              {texts.stats.map((stat, index) => {
                const StatIcon = statIconMap[stat.icon] || HomeIcon;

                return (
                  <motion.div
                    key={index}
                    variants={fadeInUp}
                  >
                    <motion.div
                      whileHover={{ y: -5, scale: 1.05 }}
                      transition={{ type: "spring", stiffness: 400 }}
                    >
                      <Card className="text-center border-none shadow-lg h-full bg-white/80 backdrop-blur-sm">
                        <CardContent className="p-6">
                          <motion.div 
                            className="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg"
                            whileHover={{ rotate: 360 }}
                            transition={{ duration: 0.6 }}
                          >
                            <StatIcon className="w-8 h-8 text-white" />
                          </motion.div>
                          <motion.div 
                            className="text-3xl font-bold bg-gradient-to-l from-blue-600 to-green-600 bg-clip-text text-transparent mb-2"
                            initial={{ scale: 0.5, opacity: 0 }}
                            whileInView={{ scale: 1, opacity: 1 }}
                            viewport={{ once: true }}
                            transition={{ 
                              type: "spring",
                              stiffness: 200,
                              delay: index * 0.1 
                            }}
                          >
                            {stat.value}
                          </motion.div>
                          <h4 className="font-bold text-gray-900 mb-1">
                            {stat.title}
                          </h4>
                          <p className="text-sm text-gray-600">
                            {stat.description}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>
      )}

      {/* Features - פיצ'רים ויכולות */}
      {texts.features && texts.features.length > 0 && (
        <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={fadeInUp}
              className="text-center mb-16"
            >
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                {texts.featuresTitle}
              </h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {texts.featuresSubtitle}
              </p>
            </motion.div>

            <motion.div 
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={staggerContainer}
              className={`grid gap-6 ${texts.features.length === 4 ? 'md:grid-cols-2 lg:grid-cols-4' : texts.features.length === 3 ? 'md:grid-cols-3' : texts.features.length === 2 ? 'md:grid-cols-2' : 'grid-cols-1 max-w-md mx-auto'}`}
            >
              {texts.features.map((feature, index) => {
                const FeatureIcon = featureIconMap[feature.icon] || Shield;

                return (
                  <motion.div
                    key={index}
                    variants={fadeInUp}
                  >
                    <motion.div
                      whileHover={{ y: -5 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <Card className="border-none shadow-md hover:shadow-lg transition-all h-full">
                        <CardContent className="p-6 text-center">
                          <motion.div 
                            className="w-14 h-14 bg-gradient-to-br from-blue-100 to-green-100 rounded-xl flex items-center justify-center mx-auto mb-4"
                            whileHover={{ scale: 1.1, rotate: 5 }}
                          >
                            <FeatureIcon className="w-7 h-7 text-blue-600" />
                          </motion.div>
                          <h4 className="font-bold text-gray-900 mb-2">
                            {feature.title}
                          </h4>
                          <p className="text-sm text-gray-600">
                            {feature.description}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>
      )}

      {/* Benefits */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {texts.benefitsTitle}
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              {texts.benefitsSubtitle}
            </p>
          </motion.div>

          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className={`grid gap-6 ${texts.benefits.length === 4 ? 'md:grid-cols-2 lg:grid-cols-4' : texts.benefits.length === 3 ? 'md:grid-cols-3' : texts.benefits.length === 2 ? 'md:grid-cols-2 max-w-3xl mx-auto' : 'grid-cols-1 max-w-md mx-auto'}`}
          >
            {texts.benefits.map((benefit, index) => {
              const BenefitIcon = iconMap[benefit.icon?.toLowerCase()] || Shield;

              return (
                <motion.div
                  key={index}
                  variants={fadeInUp}
                >
                  <motion.div
                    whileHover={{ y: -8 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Card className="text-center border-none shadow-md hover:shadow-lg transition-all h-full">
                      <CardContent className="p-6">
                        <motion.div 
                          className="w-14 h-14 bg-gradient-to-br from-blue-100 to-green-100 rounded-xl flex items-center justify-center mx-auto mb-4"
                          whileHover={{ scale: 1.15, rotate: 10 }}
                          transition={{ type: "spring", stiffness: 400 }}
                        >
                          <BenefitIcon className="w-7 h-7 text-blue-600" />
                        </motion.div>
                        <h4 className="font-bold text-gray-900 mb-2">
                          {benefit.title}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {benefit.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeInUp}
            className="text-center mb-12"
          >
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {texts.actionsTitle}
            </h3>
            <p className="text-lg text-gray-600">
              {texts.actionsSubtitle}
            </p>
          </motion.div>

          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 gap-6"
          >
            {texts.quickActions.map((action, index) => {
              const actionColor = colorMap[action.color] || colorMap.blue;

              return (
                <motion.div
                  key={index}
                  variants={fadeInUp}
                >
                  <motion.div
                    whileHover={{ scale: 1.03, y: -5 }}
                    whileTap={{ scale: 0.98 }}
                    transition={{ type: "spring", stiffness: 400 }}
                  >
                    <Card
                      className="border-none shadow-lg transition-all duration-300 cursor-pointer group h-full overflow-hidden"
                      onClick={() => action.url && window.open(action.url, '_blank')}
                    >
                      <CardContent className="p-8 relative">
                        <motion.div 
                          className={`absolute top-0 left-0 w-1 h-full bg-gradient-to-b ${actionColor.color}`}
                          whileHover={{ width: "8px" }}
                          transition={{ duration: 0.3 }}
                        />
                        <div className="flex items-start gap-4">
                          <motion.div 
                            className={`w-12 h-12 bg-gradient-to-br ${actionColor.color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-md`}
                            whileHover={{ rotate: 360, scale: 1.1 }}
                            transition={{ duration: 0.6 }}
                          >
                            <HomeIcon className="w-6 h-6 text-white" />
                          </motion.div>
                          <div className="flex-1">
                            <h4 className="text-xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                              {action.title}
                              <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-blue-600 transition-colors" />
                            </h4>
                            <p className="text-gray-600 leading-relaxed">
                              {action.description}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Email Only Option - Subtle placement */}
      {texts.showEmailOnlyOption && (
        <section className="py-12 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <Card className="border border-gray-200 bg-white/70 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Mail className="w-6 h-6 text-gray-500 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="text-lg font-semibold text-gray-800 mb-2">
                        {texts.emailOnlyTitle}
                      </h4>
                      <p className="text-sm text-gray-600 leading-relaxed">
                        {texts.emailOnlyDescription}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      )}

      {/* Contact */}
      <section id="contact" className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeInUp}
            className="text-center mb-12"
          >
            <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {texts.contactTitle}
            </h3>
            <p className="text-lg text-gray-600">
              {texts.contactSubtitle}
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={scaleIn}
          >
            <Card className="border-none shadow-xl">
              <CardContent className="p-8">
                {sent ? (
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 200 }}
                    className="text-center py-12"
                  >
                    <motion.div 
                      className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                    >
                      <CheckCircle className="w-8 h-8 text-green-600" />
                    </motion.div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">
                      ההודעה נשלחה בהצלחה!
                    </h4>
                    <p className="text-gray-600">
                      נחזור אליכם בהקדם האפשרי
                    </p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleContactSubmit} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        שם מלא
                      </label>
                      <Input
                        value={contactForm.name}
                        onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                        required
                        placeholder="הכניסו את שמכם המלא"
                        className="text-lg"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        דוא"ל <span className="text-red-500">*</span>
                      </label>
                      <Input
                        type="email"
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        required
                        placeholder="example@email.com"
                        className="text-lg"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        נוכל להתייחס לפנייתכם רק אם תכלול כתובת מייל אמיתית
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        הודעה
                      </label>
                      <Textarea
                        value={contactForm.message}
                        onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                        required
                        placeholder="כתבו כאן את ההודעה שלכם..."
                        className="min-h-[150px] text-lg"
                      />
                    </div>

                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button
                        type="submit"
                        disabled={isSending}
                        className="w-full bg-gradient-to-l from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-lg py-6"
                      >
                        {isSending ? (
                          <>שולח...</>
                        ) : (
                          <>
                            <Mail className="w-5 h-5 ml-2" />
                            שליחת הודעה
                          </>
                        )}
                      </Button>
                    </motion.div>
                  </form>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-b from-gray-900 to-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="flex flex-col items-center text-center"
          >
            <div className="flex items-center gap-3 mb-4">
              <motion.div 
                className="w-10 h-10 bg-gradient-to-br from-blue-500 to-green-500 rounded-xl flex items-center justify-center"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <HomeIcon className="w-6 h-6 text-white" />
              </motion.div>
              <span className="text-xl font-bold">{texts.siteTitle}</span>
            </div>
            <p className="text-gray-400 mb-2">
              {texts.siteTagline}
            </p>
            <p className="text-sm text-gray-500">
              © 2025 כל הזכויות שמורות
            </p>
          </motion.div>
        </div>
      </footer>
    </div>
  );
}
