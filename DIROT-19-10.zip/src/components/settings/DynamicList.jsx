
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2, GripVertical } from "lucide-react";

export default function DynamicList({ items, onChange, type }) {
  const addItem = () => {
    const newItem = type === "button"
      ? { text: "", url: "", style: "primary" }
      : type === "step"
      ? { title: "", description: "" }
      : type === "benefit"
      ? { title: "", description: "", icon: "Shield" } // Changed from "shield" to "Shield"
      : type === "stat"
      ? { title: "", value: "", description: "", icon: "home" }
      : type === "feature"
      ? { title: "", description: "", icon: "image" }
      : { title: "", description: "", url: "", color: "blue" };

    onChange([...items, newItem]);
  };

  const removeItem = (index) => {
    onChange(items.filter((_, i) => i !== index));
  };

  const updateItem = (index, field, value) => {
    const updated = [...items];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  return (
    <div className="space-y-4">
      {items.map((item, index) => (
        <Card key={index} className="border-2">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-2 cursor-move">
                <GripVertical className="w-5 h-5 text-gray-400" />
              </div>

              <div className="flex-1 space-y-3">
                {type === "button" && (
                  <>
                    <Input
                      placeholder="טקסט הכפתור"
                      value={item.text}
                      onChange={(e) => updateItem(index, "text", e.target.value)}
                    />
                    <Input
                      placeholder="קישור (URL)"
                      value={item.url}
                      onChange={(e) => updateItem(index, "url", e.target.value)}
                    />
                    <Select
                      value={item.style}
                      onValueChange={(value) => updateItem(index, "style", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="primary">ראשי (כחול)</SelectItem>
                        <SelectItem value="secondary">משני (ירוק)</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                )}

                {type === "step" && (
                  <>
                    <Input
                      placeholder="כותרת השלב"
                      value={item.title}
                      onChange={(e) => updateItem(index, "title", e.target.value)}
                    />
                    <Textarea
                      placeholder="תיאור השלב"
                      value={item.description}
                      onChange={(e) => updateItem(index, "description", e.target.value)}
                      className="min-h-[80px]"
                    />
                  </>
                )}

                {type === "benefit" && (
                  <>
                    <Input
                      placeholder="כותרת היתרון"
                      value={item.title}
                      onChange={(e) => updateItem(index, "title", e.target.value)}
                    />
                    <Input
                      placeholder="תיאור היתרון"
                      value={item.description}
                      onChange={(e) => updateItem(index, "description", e.target.value)}
                    />
                    <Select
                      value={item.icon}
                      onValueChange={(value) => updateItem(index, "icon", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Shield">מגן</SelectItem> {/* Value changed */}
                        <SelectItem value="Clock">שעון</SelectItem> {/* Value changed */}
                        <SelectItem value="Users">משתמשים</SelectItem> {/* Value changed */}
                        <SelectItem value="Heart">לב</SelectItem>     {/* Value changed */}
                        <SelectItem value="Star">כוכב</SelectItem>     {/* Value changed */}
                        <SelectItem value="Zap">ברק</SelectItem>      {/* Value changed */}
                      </SelectContent>
                    </Select>
                  </>
                )}

                {type === "stat" && (
                  <>
                    <Input
                      placeholder="כותרת (למשל: דירות במערכת)"
                      value={item.title}
                      onChange={(e) => updateItem(index, "title", e.target.value)}
                    />
                    <Input
                      placeholder="ערך מספרי (למשל: 500+)"
                      value={item.value}
                      onChange={(e) => updateItem(index, "value", e.target.value)}
                    />
                    <Input
                      placeholder="תיאור (למשל: דירות פעילות)"
                      value={item.description}
                      onChange={(e) => updateItem(index, "description", e.target.value)}
                    />
                    <Select
                      value={item.icon}
                      onValueChange={(value) => updateItem(index, "icon", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="home">בית</SelectItem>
                        <SelectItem value="users">משתמשים</SelectItem>
                        <SelectItem value="trending">עולה</SelectItem>
                        <SelectItem value="check">V</SelectItem>
                        <SelectItem value="star">כוכב</SelectItem>
                        <SelectItem value="heart">לב</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                )}

                {type === "feature" && (
                  <>
                    <Input
                      placeholder="כותרת הפיצ'ר (למשל: תמיכה בתמונות)"
                      value={item.title}
                      onChange={(e) => updateItem(index, "title", e.target.value)}
                    />
                    <Textarea
                      placeholder="תיאור הפיצ'ר"
                      value={item.description}
                      onChange={(e) => updateItem(index, "description", e.target.value)}
                      className="min-h-[80px]"
                    />
                    <Select
                      value={item.icon}
                      onValueChange={(value) => updateItem(index, "icon", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="image">תמונה</SelectItem>
                        <SelectItem value="database">מסד נתונים</SelectItem>
                        <SelectItem value="clock">שעון</SelectItem>
                        <SelectItem value="shield">מגן</SelectItem>
                        <SelectItem value="zap">ברק</SelectItem>
                        <SelectItem value="bell">פעמון</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                )}

                {type === "action" && (
                  <>
                    <Input
                      placeholder="כותרת הפעולה"
                      value={item.title}
                      onChange={(e) => updateItem(index, "title", e.target.value)}
                    />
                    <Input
                      placeholder="תיאור הפעולה"
                      value={item.description}
                      onChange={(e) => updateItem(index, "description", e.target.value)}
                    />
                    <Input
                      placeholder="קישור (URL)"
                      value={item.url}
                      onChange={(e) => updateItem(index, "url", e.target.value)}
                    />
                    <Select
                      value={item.color}
                      onValueChange={(value) => updateItem(index, "color", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="blue">כחול</SelectItem>
                        <SelectItem value="green">ירוק</SelectItem>
                        <SelectItem value="orange">כתום</SelectItem>
                        <SelectItem value="purple">סגול</SelectItem>
                        <SelectItem value="pink">ורוד</SelectItem>
                        <SelectItem value="red">אדום</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                )}
              </div>

              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => removeItem(index)}
                className="flex-shrink-0 text-red-500 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}

      <Button
        type="button"
        variant="outline"
        onClick={addItem}
        className="w-full border-dashed border-2"
      >
        <Plus className="w-4 h-4 ml-2" />
        הוספת פריט
      </Button>
    </div>
  );
}
